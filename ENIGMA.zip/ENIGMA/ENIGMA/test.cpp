#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <windows.h>
#include <ctime>
#include <cctype>	
using namespace std;


bool isDigit(string inp){
    return all_of(inp.begin(), inp.end(), ::isdigit);
}
int keyInput(){
        
		string key = "";
		while(true){
            cin >> key;
            if(isDigit(key)){
                return std::stoi(key);
            }
            else {
                continue;
            }
        }
      

	}
int main(){
	int key;
	key=keyInput();
	cout<<endl<<key;
}